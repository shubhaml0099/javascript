

let bodyElement = document.querySelector('body')


bodyElement.addEventListener('click',function(event){


    console.log(event.target.tagName)


})

