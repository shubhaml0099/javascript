// <h1 class="red" id = "green" name ="nam">hello</h1>

// DOM is object 


let headingOone =  document.querySelector('h1')
console.log(headingOone)

let para = document.querySelector('p')

// retrive
console.log(para['textContent'])








// document.querySelector('h1[name="nam"]')
// document.querySelector('h1[class="red"]')
// document.querySelector('h1[id="green"]')

// // id 
// document.querySelector('#green')
// document.querySelector('.red')
 //tagName[attribute="value"]


// let human = {
//     age:12,
//     skills:["html","del"]
// }

// // update 

// human.age = 22
// // add 

// human.roll = 23

// // dele 

// delete human.age 

// // retrive 

// human.skills












 // javascript -----> 

 //you  can create element 
 // you can update element 
 // you can retrive element 
 // you can delete element 

 // attribute 

 //you  can add attribute 
 // you can update attribute 
 // you can delete attribute 
 // you can also value of attribute


 // madhuri // snehal // shraddha 
 // godavari // girija