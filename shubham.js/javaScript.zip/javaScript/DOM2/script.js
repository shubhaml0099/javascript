

let headOne = document.querySelector('h1')
let button = document.querySelector('button')


console.log(headOne)
console.log(button)


button.addEventListener('click',function(){
    headOne.style.color = "yellow"
    headOne.style.backgroundColor ="red"

})
//human.parent.father = "amol"
// let human = {
//     age:12,
//     parent:{
//         father:"shirish",
//         mother:"kanchan"
//     }

// }

// human.parent.father = "amol"
// human['parent']['mother'] = "rasika"
